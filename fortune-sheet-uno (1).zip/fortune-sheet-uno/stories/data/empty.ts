const data = {
  name: "Empty",
  status: 1,
  celldata: [{ r: 0, c: 0, v: null }],
};

export default data;

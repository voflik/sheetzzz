export default {
  target: 'browser',
  cjs: { type: "rollup", lazy: false },
  esm: { type: "rollup" },
  disableTypeCheck: false,
  pkgs: ['core', 'react'],
};

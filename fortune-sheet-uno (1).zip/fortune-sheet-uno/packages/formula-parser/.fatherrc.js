export default {
  target: 'browser',
  cjs: { type: "babel", lazy: true },
  esm: { type: "babel" },
  disableTypeCheck: false,
};

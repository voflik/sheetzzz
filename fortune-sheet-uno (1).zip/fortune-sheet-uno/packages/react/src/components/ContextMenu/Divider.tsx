import React from "react";

const Divider: React.FC = () => {
  return <div className="fortune-context-menu-divider" />;
};

export default Divider;

# @fortune-sheet/react

FortuneSheet is a drop-in javascript spreadsheet library that provides rich features like Excel and Google Sheets

See our repo [fortune-sheet](https://github.com/ruilisi/fortune-sheet) for more information.

## Install

Using npm:

```bash
$ npm install --save  @fortune-sheet/react
```

or using yarn:

```bash
$ yarn add @fortune-sheet/react
```
